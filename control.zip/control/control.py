from lib.cli import *
from color import *
import importlib
import sys,os,re
#requests.packages.urllib3.disable_warnings() # 禁用安全警告

if __name__ == '__main__':
######################################################################
    # 需要python3 版本
    if sys.version_info < (3, 0):
        sys.stdout.write("Error, Tolerance 需要 Python 3.x\n")
        sys.exit(1)
######################################################################
    #运行主体命令
    Command_dict=getparameter()

    #疑似询关键词的漏洞主体
    Judgement_parameter(Command_dict)



