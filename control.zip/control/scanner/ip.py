import numpy as np
import requests
import os
import time
from socket import gethostbyname

def run(target):
	str1 = target
	str2 = str1.replace('http://','')
	str3 = str2.replace('https://','')
	kks=str3
	ukm = gethostbyname(kks)
	apikey='8dabc1a3bc3152ee'
	url0 ='https://api.muxiaoguo.cn/api/ip?'
	url1='ip=' + ukm
	url2='&type=m'
	url3='&api_key='+apikey
	url=url0+url1+url2+url3
	r = requests.get(url)
	#print(r.text)
	#print(r.status_code)
	req_jason = r.json() # 获取数据
	code_trunk = req_jason['data']
	print('状态码： %s' % r.status_code)
	ip_trunk = code_trunk['ip']
	print('ipv4地址: %s' % ip_trunk)
	country_trunk = code_trunk['country']
	print('国家/地区/组织: %s' % country_trunk)
	province_trunk = code_trunk['province']
	print('省/自治区/直辖市: %s' % province_trunk)
	city_trunk = code_trunk['city']
	print('地级市: %s' % city_trunk)
	area_trunk = code_trunk['area']
	print('县/区/镇/街道: %s' % area_trunk)
	address_trunk = code_trunk['address']
	print('详细地址: %s' % address_trunk)
	location_trunk = code_trunk['location']
	print('运营商/节点: %s' % location_trunk)
	updateTime_trunk = code_trunk['updateTime']
	print('更新时间: %s' % updateTime_trunk)



if __name__ == '__main__':
	run('https://www.qq.com')
