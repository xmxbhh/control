import numpy as np
import requests
import os
import time


def run(target):
	url=target
	apikey='fc1ee05368503ac4'
	url0 ='https://api.muxiaoguo.cn/api/ICP?'
	url1='url=' + url
	url3='&api_key='+apikey
	url=url0+url1+url3
	r = requests.get(url)
	#print(r.text)
	#print(r.status_code)
	req_jason = r.json() # 获取数据
	code_trunk = req_jason['data']
	
	print('状态码： %s' % r.status_code)
	url_trunk = code_trunk['url']
	print('被查询的域名: %s' % url_trunk )
	organizer_name_trunk = code_trunk['organizer_name']
	print('企业名: %s' % organizer_name_trunk)
	nature_trunk = code_trunk['nature']
	print('备案性质 : %s' % nature_trunk)
	license_trunk = code_trunk['license']
	print('备案号: %s' % license_trunk)
	website_name_trunk = code_trunk['website_name']
	print('网站名称: %s' % website_name_trunk)
	website_home_trunk = code_trunk['website_home']
	print('首页域名: %s' % website_home_trunk)
	audit_time_trunk = code_trunk['audit_time']
	print('审核日期: %s' % audit_time_trunk)

if __name__ == '__main__':
	run('https://www.qq.com')
