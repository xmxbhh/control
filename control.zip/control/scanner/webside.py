# -*- coding:utf-8 -*-

import requests
import json
import socket

header = {
    'Host': 'api.webscan.cc',
    'Origin': 'http://webscan.cc',
    'Pragma': 'no-cache',
    'Referer': 'http://webscan.cc/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132'
}

def get_ips_for_host(host):
        try:
            ips = socket.gethostbyname(host.replace('http://','').replace('https://','').replace('/',''))
        except socket.gaierror:
            print(host)
            ips=[]
        return ips


def run(target):
    """
    获取旁站信息
    :param ip:
    :return:
    """
    ip=get_ips_for_host(target)
    api_url = 'http://api.webscan.cc/'
    query_data = {
        'action': 'query',
        'ip': ip
    }
    try:
        html = requests.post(api_url, data=query_data, headers=header, timeout=8)
        text = html.text
        if text.startswith(u'\ufeff'):
            text = text.encode('utf8')[3:].decode('utf8')
        if text.find('null') > -1:
            return False
        else:
            return json.loads(text)
    except Exception as e:
        pass
    return False
