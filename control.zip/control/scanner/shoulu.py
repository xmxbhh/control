import numpy as np
import requests
import os
import time


def run(target):
	str1 = target
	str2 = str1.replace('http://','')
	str3 = str2.replace('https://','')
	url=str3
	apikey='b84e4381484145a9'
	url0 ='https://api.muxiaoguo.cn/api/shoulu?'
	url1='url=' + url
	url3='&api_key='+apikey
	url=url0+url1+url3
	r = requests.get(url)
	#print(r.text)
	#print(r.status_code)
	req_jason = r.json() # 获取数据
	code_trunk = req_jason['data']
	print('状态码： %s' % r.status_code)
	baidu_trunk = code_trunk['baidu']
	print('百度共收录: %s' % baidu_trunk)


if __name__ == '__main__':
	run('https://www.qq.com')
