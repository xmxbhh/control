import numpy as np
import requests
import os
import time


def run(target):
	url=target
	apikey='e5d3e679e9bc852f'
	url0 ='https://api.muxiaoguo.cn/api/whois?'
	url1='url=' + url
	url3='&api_key='+apikey
	url=url0+url1+url3
	r = requests.get(url)
	#print(r.text)
	#print(r.status_code)
	req_jason = r.json() # 获取数据
	code_trunk = req_jason['data']
	
	print('状态码： %s' % r.status_code)
	url_trunk = code_trunk['url']
	print('查询主域: %s' % url_trunk )
	whois_server_trunk = code_trunk['whois_server']
	print('注册商WHOIS服务器: %s' % whois_server_trunk)
	registrar_url_trunk = code_trunk['registrar_url']
	print('注册商网址: %s' % registrar_url_trunk)
	updated_date_trunk = code_trunk['updated_date']
	print('更新日期: %s' % updated_date_trunk)
	creation_date_trunk = code_trunk['creation_date']
	print('注册日期: %s' % creation_date_trunk)
	expiration_date_trunk = code_trunk['expiration_date']
	print('过期日期: %s' % expiration_date_trunk)
	registrar_trunk = code_trunk['registrar']
	print('注册机构/注册人: %s' % registrar_trunk)
	email_trunk = code_trunk['email']
	print('电子邮箱: %s' % email_trunk)
	phone_trunk = code_trunk['phone']
	print('手机号码: %s' % phone_trunk)
	
if __name__ == '__main__':
	run('https://www.qq.com')
