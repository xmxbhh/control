import os
import importlib
from lib.data import logger
import threading
import platform   #判断操作系统
import sys

mutex = threading.Lock()
#线程列表
threads = []
def isDir(apath):
    if not os.path.isdir(apath):
        logger.warning("%s is not a directory! " % apath)
        raise EnvironmentError
    logger.info("Plugin path: %s " % apath)
def ajiazai(url, items, pay, dirname):
    if pay != '' and pay !='all':
        logger.info('Loading scanner with "%s" key words.' % pay)
        for item in items:
            if item.endswith(".py") and not item.startswith('__'):
                plugin_name = item[:-3]
                if pay in plugin_name:
                    logger.info("Loading plugin: %s" % plugin_name)
                    module = importlib.import_module(dirname + '.' + plugin_name)
                    try:
                        result = module.run(url)
                        if result:
                            logger.success(result)
                        else:
                            logger.error("Not Vulnerable %s " % plugin_name)
                    except:
                        logger.warning("ConnectionError ")
                else:
                    continue
    else:
        pay = ''
        for item in items:
            thread = threading.Thread(target=load, args=(url, item, pay, dirname))
            threads.append(thread)
            thread.start()
    return
def load(url, item, pay, dirname):
    if item.endswith(".py") and not item.startswith('__'):
        plugin_name = item[:-3]
        if pay in plugin_name:
            mutex.acquire()
            logger.info("Loading plugin: %s" % plugin_name)
            module = importlib.import_module(dirname + '.' + plugin_name)
            try:
                result = module.run(url)
                if result:
                    logger.success(result)
                else:
                    logger.error("Not Vulnerable %s " % plugin_name)
            except:
                logger.warning("%s" % plugin_name + " ConnectionError ")
            mutex.release()
        else:
            mutex.release()
            pass
def load_exp_or_plugin(url,poc = None, exp = None, sca=None ):
    dirname = ''
    if exp:
        apath = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "exp")
        if(platform.system()=='Windows'):
                dirname = apath[apath.rfind('\\') + 1:]
                pay = exp
        else:
                dirname = apath[apath.rfind('/') + 1:]
                pay = exp
    elif poc!=None and sca==None :
        apath = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "plugins")
        if(platform.system()=='Windows'):
                dirname = apath[apath.rfind('\\') + 1:]
                pay = poc
        else:
                dirname = apath[apath.rfind('/') + 1:]
                pay = poc
    elif poc==None and sca==None:
        apath = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "plugins")
        if(platform.system()=='Windows'):
                dirname = apath[apath.rfind('\\') + 1:]
                pay = ''
        else:
                dirname = apath[apath.rfind('/') + 1:]
                pay = ''
    elif sca =='all':
        apath = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "scanner")
        if(platform.system()=='Windows'):
                dirname = apath[apath.rfind('\\') + 1:]
                pay = sca
        else:
                dirname = apath[apath.rfind('/') + 1:]
                pay = sca
    else:
        apath = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "scanner")
        if(platform.system()=='Windows'):
                dirname = apath[apath.rfind('\\') + 1:]
                pay = sca
        else:
                dirname = apath[apath.rfind('/') + 1:]
                pay = sca
    #判断加载的是否是一个目录
    isDir(apath)
    items = os.listdir(apath)
    ajiazai(url, items, pay, dirname)
    return
def loadPlugin(url, poc=None, sca=None, ex=None):
    if url == None:
    	sys.exit(0)
    if "://" not in url:
        url = "http://" + url
    url = url.strip("/")
    logger.info("Target url: %s" % url)
    logger.info("Your system: %s" %platform.system())


    load_exp_or_plugin(url, poc, ex, sca)
    for t in threads:
        t.join()
    logger.info("Finished")

