from lib.cmdline import *
import sys,os,re
from lib.loader import loadPlugin
from colorama import Fore
from color import *
######################################################################
#得到输入的参数进行判断
def getparameter():
    # 获取命令行所有参数
    Command = sys.argv
    # print(Command)
    Command_dict = {}
    #判断互斥参数:
    if "-u" in Command and  "-f" in Command :
        print(color.red("[E]Error:参数值设置错误！"))
        sys.exit(1)
    #帮助信息
    if  len(sys.argv) ==1 or "-h" in Command:
        # 输出帮助信息
        logo()
        total_menu()
        sys.exit(1)
    elif  len(sys.argv) ==1 or "-sl" in Command:
        logo()
        scan_menu()
        sys.exit(1)
    elif  len(sys.argv) ==1 or "-eh" in Command:
        # 列出所有漏洞
        help_menu()
        sys.exit(1)
    try:
        #列表每次取兩个元素
        for i in range(1, len(Command), 2):
            # print(Command[i])
            Command_dict[Command[i]] = Command[i + 1]
            #转化为字典
        return(Command_dict)
    except:
        logo()
        print(color.red("[E]Error:参数值设置错误！"))
        sys.exit(1)
    #如果参数字典为空  输出帮助
    if not Command_dict:
        logo()
        total_menu()
        sys.exit(1)
    #否则返回参数
    else:
        return Command_dict
######################################################################   
def Judgement_parameter(Command_dict):
##########################
	if "-u" in Command_dict:
		url =Command_dict['-u']
	else:
		print(color.red('未获取到URL地址!'))
		url = None
##########################
	if "-m" in Command_dict:
		plugin=Command_dict['-m']
	else:
        	plugin = None
##########################
	if "-s" in Command_dict or "-S" in Command_dict :
		if "-s" in Command_dict:
			scan =Command_dict['-s']
		if "-S" in Command_dict:
			scan =Command_dict['-S']
	else:
        	scan = None
##########################
	if "-e" in Command_dict:
	        exp =Command_dict['-e']
	else:
        	exp = None
#######################################       	
	loadPlugin(url=url, poc=plugin, sca=scan, ex=exp)   
######################################################################

