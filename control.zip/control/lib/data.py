from lib.log import MyLogger

logger = MyLogger